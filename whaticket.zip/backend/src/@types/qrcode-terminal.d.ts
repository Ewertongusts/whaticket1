declare module "qrcode-terminal";
